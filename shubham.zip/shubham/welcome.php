<html>
<head>
</head>
<body>
<?php
session_start();
if(isset($_SESSION['name'])){
	echo "<h2 style='color:green;text-align:center'>Welcome, "." ". $_SESSION['name']."<h2>";
} 
?>
<body>
</html>